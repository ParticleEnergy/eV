﻿// See https://aka.ms/new-console-template for more information

using System.Net;
using System.Net.Sockets;
using eV.ServerUdpExample;

var socket = new Socket(AddressFamily.InterNetwork, SocketType.Dgram, ProtocolType.Udp);

// 广播
socket.SetSocketOption(SocketOptionLevel.Socket, SocketOptionName.Broadcast, true);
// //设置多播
// socket.SetSocketOption(SocketOptionLevel.IP, SocketOptionName.MulticastLoopback, true);
//
var multicastOption = new MulticastOption(IPAddress.Parse("234.5.6.111"), IPAddress.Parse("192.168.2.108"));

socket.SetSocketOption(SocketOptionLevel.IP, SocketOptionName.AddMembership, multicastOption);
// IP 多路广播生存时间
// socket.SetSocketOption(SocketOptionLevel.IP, SocketOptionName.MulticastTimeToLive, 10);

socket.Bind(new IPEndPoint(IPAddress.Any, 8888));

Receive receive = new(socket);

Console.ReadLine();
